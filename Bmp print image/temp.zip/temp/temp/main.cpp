#include <iostream>
#include <stdio.h>
#include <string.h>
#include "bmp.h"

using namespace std;

#define BMP_SOURCE		"lenna.bmp"

void changeBmp(PixelArray& p)
{
	for (int i = 0; i < p.rowCount; i++)
		for (int j = 0; j < p.columnCount; j++)
		{
			Color* c = &p.pixels[i][j];
			int avg = 0.85 * c->red + 0.1 * c->green + 0.05 * c->blue;

			c->red = avg;
			c->green = avg;
			c->blue = avg;
		}
}

void demoReadBmp()
{
	BmpFile bmpSource;

	readBmpFile((char*)BMP_SOURCE, bmpSource);
	printBmpHeader(bmpSource);
	printBmpDib(bmpSource);

	getchar();
	system("cls");

	//changeBmp(bmpSource.pixelArray);
	drawBmp(bmpSource);
	releaseBmpPixelArray(bmpSource);
}

void main()
{
	demoReadBmp();
}